package ru.pricechecker.ozonwb

import android.content.Context

class PriceChecker(private val context: Context) {
    fun checkAll() {
        val repo = ProductRepository(context)
        repo.getProducts().forEach { product ->
            try {
                val result = PriceFetcher.fetch(product.url)
                repo.update(product.id, result.title, result.price)
                if (product.price != null && result.price != null && product.price != result.price) {
                    NotificationHelper.show(
                        context,
                        product.title,
                        "Цена изменилась: ${format(product.price)} ₽ → ${format(result.price)} ₽"
                    )
                }
            } catch (_: Exception) {
                // Ошибка одной карточки не должна останавливать проверку остальных.
            }
        }
    }

    private fun format(v: Double) = "%.0f".format(v)
}
