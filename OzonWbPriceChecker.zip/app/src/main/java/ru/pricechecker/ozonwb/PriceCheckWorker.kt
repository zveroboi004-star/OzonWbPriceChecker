package ru.pricechecker.ozonwb

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class PriceCheckWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        return try {
            PriceChecker(applicationContext).checkAll()
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
