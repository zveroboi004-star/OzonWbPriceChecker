package ru.pricechecker.ozonwb

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var repo: ProductRepository
    private lateinit var adapter: ProductAdapter
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100
            )
        }

        repo = ProductRepository(this)
        adapter = ProductAdapter(repo.getProducts()) { product ->
            repo.delete(product.id)
            refresh()
        }

        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        status = findViewById(R.id.statusText)

        findViewById<Button>(R.id.addButton).setOnClickListener {
            val url = findViewById<EditText>(R.id.urlInput).text.toString().trim()
            when {
                url.isEmpty() -> toast("Вставьте ссылку")
                !PriceFetcher.isSupported(url) -> toast("Поддерживаются ссылки Ozon и Wildberries")
                else -> {
                    repo.add(url)
                    findViewById<EditText>(R.id.urlInput).text.clear()
                    refresh()
                }
            }
        }

        findViewById<Button>(R.id.checkButton).setOnClickListener {
            status.text = "Проверяем..."
            Thread {
                PriceChecker(this).checkAll()
                runOnUiThread {
                    status.text = "Проверка завершена"
                    refresh()
                }
            }.start()
        }

        scheduleChecks()
        refresh()
    }

    private fun scheduleChecks() {
        val request = PeriodicWorkRequestBuilder<PriceCheckWorker>(20, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "price-check",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    private fun refresh() {
        adapter.setItems(repo.getProducts())
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
