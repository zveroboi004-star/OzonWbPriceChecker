package ru.pricechecker.ozonwb

import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.regex.Pattern

data class PriceResult(val title: String, val price: Double?)

object PriceFetcher {
    fun isSupported(url: String): Boolean =
        url.contains("ozon.ru", true) || url.contains("wildberries.ru", true) ||
        url.contains("wb.ru", true)

    fun fetch(url: String): PriceResult {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 20000
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) AppleWebKit/537.36 Chrome/130 Mobile")
        connection.setRequestProperty("Accept-Language", "ru-RU,ru;q=0.9")
        connection.instanceFollowRedirects = true
        return try {
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val title = extractTitle(html)
            val price = extractPrice(html)
            PriceResult(title, price)
        } finally {
            connection.disconnect()
        }
    }

    private fun extractTitle(html: String): String {
        val patterns = listOf(
            Regex("""<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']""", RegexOption.IGNORE_CASE),
            Regex("""<title[^>]*>(.*?)</title>""", RegexOption.IGNORE_CASE)
        )
        for (p in patterns) {
            val m = p.find(html)
            if (m != null) return android.text.Html.fromHtml(m.groupValues[1]).toString().trim()
        }
        return "Товар"
    }

    private fun extractPrice(html: String): Double? {
        val candidates = mutableListOf<Double>()
        val regexes = listOf(
            Regex(""""price"\s*:\s*"?(\\d+(?:[.,]\\d+)?)""", RegexOption.IGNORE_CASE),
            Regex(""""price\s*:\s*(\\d+(?:[.,]\\d+)?)""", RegexOption.IGNORE_CASE),
            Regex("""(\d{1,3}(?:[ \u00A0]\d{3})*(?:[.,]\d{2})?)\s*(?:₽|руб)""", RegexOption.IGNORE_CASE)
        )
        for (r in regexes) {
            r.findAll(html).take(30).forEach { m ->
                val raw = m.groupValues[1].replace(" ", "").replace("\u00A0", "").replace(",", ".")
                raw.toDoubleOrNull()?.let { if (it in 1.0..5_000_000.0) candidates += it }
            }
        }
        return candidates.minOrNull()
    }
}
