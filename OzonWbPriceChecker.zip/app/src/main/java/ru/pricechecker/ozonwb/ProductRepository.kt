package ru.pricechecker.ozonwb

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ProductRepository(context: Context) {
    private val prefs = context.getSharedPreferences("products", Context.MODE_PRIVATE)

    fun getProducts(): MutableList<Product> {
        val json = prefs.getString("items", "[]") ?: "[]"
        val a = JSONArray(json)
        val result = mutableListOf<Product>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            result += Product(
                o.getLong("id"),
                o.getString("url"),
                o.getString("marketplace"),
                o.optString("title", "Товар"),
                if (o.isNull("price")) null else o.getDouble("price"),
                if (o.isNull("previousPrice")) null else o.getDouble("previousPrice"),
                o.optLong("updatedAt", 0)
            )
        }
        return result
    }

    fun add(url: String) {
        val list = getProducts()
        if (list.any { it.url == url }) return
        val marketplace = if (url.contains("wildberries", true) || url.contains("wb.ru", true)) "WB" else "Ozon"
        list += Product(System.currentTimeMillis(), url, marketplace)
        save(list)
    }

    fun delete(id: Long) = save(getProducts().filterNot { it.id == id })

    fun update(id: Long, title: String, price: Double?) {
        val list = getProducts()
        val old = list.firstOrNull { it.id == id } ?: return
        val updated = old.copy(
            title = title,
            previousPrice = old.price,
            price = price,
            updatedAt = System.currentTimeMillis()
        )
        save(list.map { if (it.id == id) updated else it })
    }

    private fun save(list: List<Product>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().apply {
                put("id", it.id)
                put("url", it.url)
                put("marketplace", it.marketplace)
                put("title", it.title)
                if (it.price == null) put("price", JSONObject.NULL) else put("price", it.price)
                if (it.previousPrice == null) put("previousPrice", JSONObject.NULL) else put("previousPrice", it.previousPrice)
                put("updatedAt", it.updatedAt)
            })
        }
        prefs.edit().putString("items", a.toString()).apply()
    }
}
