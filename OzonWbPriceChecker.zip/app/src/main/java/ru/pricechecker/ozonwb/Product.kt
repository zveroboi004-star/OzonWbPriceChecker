package ru.pricechecker.ozonwb

data class Product(
    val id: Long,
    val url: String,
    val marketplace: String,
    val title: String = "Товар",
    val price: Double? = null,
    val previousPrice: Double? = null,
    val updatedAt: Long = 0L
)
